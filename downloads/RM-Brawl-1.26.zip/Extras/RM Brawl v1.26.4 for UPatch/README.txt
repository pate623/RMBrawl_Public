+--------------------------------------------------------------------------------------+
|****************************** AoE:UPatch Installation *******************************|
+--------------------------------------------------------------------------------------+
1. copy the "RM Brawl" folder from "RM Brawl, AoE UPatch" folder.
2. Paste it into the "Mods" folder.
	The default "Mods" folder can be found at:
	C:\Program Files (x86)\Microsoft Games\Age of Empires\Mods

for more information on how to install mods on UPatch visit:
https://upatch-hd.weebly.com/using-mods.html

zip file "RM-Brawl-1.26.4U-tech-trees" holds technology trees.
It isn't required to play the game, it is just for additional information.
patchNotes.pdf file inside the mod folder holds information about all the changes.


+--------------------------------------------------------------------------------------+
|************************************* Change Log *************************************|
+--------------------------------------------------------------------------------------+
Patch 1.26.4
Medium Wall (Upgrade), Food cost 180 -> 260
Yamato, Bonus removed; Granary upgrades cost -70%

This is the last patch with new units. 
The final release of 1.27 will remove all new units.


Patch 1.26.3
Changed Medium Wall hit points from 300 to 250


Patch 1.26.2.7
Bug fixes: Berbers
Missing last melee armor upgrade| fixed
Missing war ship upgrades	| fixed
Missing Scythe Chariot		| fixed

Bug fixes: Parthia
Does not train military units!  | Fixed
 -Can't research Heavy Camel	| Fixed
 -Won't train Elephants  	| Fixed

Bug fixes: Thrace
Missing war ship upgrades | Fixed
Missing Heavy Cavalry	  | Fixed

Bug fixes: Scythia
Doesn't upgrade Catapults | Fixed


Patch 1.26.2.6
New Civilizations AI rework
Berbers | Created
Parthia | Created
Scythia | Created
Thrace  | Created


Patch 1.26.2.5
AI Update
Persia: Can use the wood cost Temple technologies.
Creel: Removed from the list.
Yamato: Can research granary technologies.
Palmyra: Added Metallurgy.
Minoan: Can use Dock technologies.


Patch 1.26.2.4
Changed Scythia bonus:
Aging up is 10% cheaper -> Villagers benefit from armor upgrades


Patch 1.26.2.3
Added Scythia without age up cost reduction.
Todo; add age up cost reduction to Scythia.


Patch 1.26.2.2
Thrace bonus changed
Houses get +1 headroom on age up -> Foragers work 25% more efficiently
Thrace is now finished, only Scythia left.


Patch 1.26.2.1
Added Berbers and Parthia
No changes to Scythia
Thrace has couple bugs but is othervise ready:
 -House bonus won't grant extra headroom on age up.
 -On destructon old houses removed more headroom than they gave.


Patch 1.26.2
Included changes to the 16 base civilizations.
the 4 new civlizations are reseted to full tech tree.


Patch 1.26.1
Includes unit change listed in the mod read me under the
Patch 1.27 General Changes (Tentative) section.
Doesn't include civilization changes, except the removed Creel and added Spearman.


+--------------------------------------------------------------------------------------+
|************************************** Credits ***************************************|
+--------------------------------------------------------------------------------------+
Advanced Genie Editor
http://aok.heavengames.com/blacksmith/showfile.php?fileid=11002
	Used for editing empires.dat file

Mery SLP
https://github.com/MeryKitty/meryslp
	Used for editing .SLP files in AOE:DE

Turtle Pack
http://aok.heavengames.com/blacksmith/showfile.php?fileid=11349
	Used for editing .DRS and .SLP files

SLX Studio
http://aok.heavengames.com/blacksmith/showfile.php?fileid=13179
	Used for editing .SLP files in AOE:RoR

Heavy Slinger graphics
http://aoe.heavengames.com/dl-php/showfile.php?fileid=2585
	Used for Bronze Age and Iron Age Slinger graphics

Heavy Camel graphics
https://aoe.heavengames.com/dl-php/showfile.php?fileid=2590
	Used for Iron Age Camel Rider graphics


+--------------------------------------------------------------------------------------+
|*************************************** More *****************************************|
+--------------------------------------------------------------------------------------+
for more information about this mod visit:
http://rmbrawl.net