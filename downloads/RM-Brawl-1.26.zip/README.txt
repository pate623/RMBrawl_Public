+--------------------------------------------------------------------------------------+
|******************************** AoE:DE Installation *********************************|
+--------------------------------------------------------------------------------------+
1. Copy all the files from "RM Brawl, AoE Definitive Edition" folder
2. Paste these files into the AOE:DE installation folder.
	The default installation folder can be found at:
	C:\Program Files (x86)\Steam\steamapps\common\AoEDE
  Make sure you click replace all the files (151).



+--------------------------------------------------------------------------------------+
|****************************** AoE:UPatch Installation *******************************|
+--------------------------------------------------------------------------------------+
1. copy the "RM Brawl" folder from "RM Brawl, AoE UPatch" folder.
2. Paste it into the "Mods" folder.
	The default "Mods" folder can be found at:
	C:\Program Files (x86)\Microsoft Games\Age of Empires\Mods

for more information on how to install mods on UPatch visit:
https://upatch-hd.weebly.com/using-mods.html



+--------------------------------------------------------------------------------------+
|*************************************** Extras ***************************************|
+--------------------------------------------------------------------------------------+
				*** Tree Draw Levels ***
Tree Draw level changes the draw levels of all trees to a level 10 causing all units 
behind tress be visible at all times.

This change is available to:
	AoE UPatch, RM Brawl
	AoE:DE, RM Brawl
	AoE:DE v46777


To install this mod to Age of empires definitive edition v46777:
Replace the "empires-mod.dat" file from AoE:DE installation folder
with the "empires-mod.dat" file from the folder: Extras\Tree Draw Levels\AoE DE v46777
Default "empires-mod.dat" file location is:
	C:\Program Files (x86)\Steam\steamapps\common\AoEDE\Data


To install this mod to Age of empires definitive edition; RM Brawl:
Replace the "empires-mod.dat" file from AoE:DE installation folder
with the "empires-mod.dat" file from the folder: Extras\Tree Draw Levels\RM Brawl AoE DE
Default "empires-mod.dat" file location is:
	C:\Program Files (x86)\Steam\steamapps\common\AoEDE\Data


To install this mod to Age of empires User Patch; RM Brawl:
Replace the "empires-mod.dat" file from RMBrawl Mods folder
with the "empires-mod.dat" file from the folder: Extras\Tree Draw Levels\RM Brawl, UPatch
Default "empires-mod.dat" file location is:
	C:\Program Files (x86)\Microsoft Games\Age of Empires\Mods\RM Brawl



			     *** Player Color Editor ***
This tool is used to edit player colors in Age of Empires Definitive edition.
This tool works with all the Age of Empires Definitive Edition versions.

To use this extra the .zip file and run "Player Color Editor.exe" program.

More info can be found within this program by clicking the "?" button.



		        *** RM Brawl v1.26.4 for UPatch ***
This is the last version of RM Brawl containing all of the new units.



+--------------------------------------------------------------------------------------+
|************************************** Credits ***************************************|
+--------------------------------------------------------------------------------------+
Advanced Genie Editor
http://aok.heavengames.com/blacksmith/showfile.php?fileid=11002
	Used for editing empires.dat file

Mery SLP
https://github.com/MeryKitty/meryslp
	Used for editing .SLP files in AOE:DE

Turtle Pack
http://aok.heavengames.com/blacksmith/showfile.php?fileid=11349
	Used for editing .DRS and .SLP files

Heavy Slinger graphics
http://aoe.heavengames.com/dl-php/showfile.php?fileid=2585
	Used for Bronze Age and Iron Age Slinger graphics

Heavy Camel graphics
https://aoe.heavengames.com/dl-php/showfile.php?fileid=2590
	Used for Iron Age Camel Rider graphics


+--------------------------------------------------------------------------------------+
|*************************************** More *****************************************|
+--------------------------------------------------------------------------------------+
for more information about this mod visit:
http://rmbrawl.net
